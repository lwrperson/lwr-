package com.zpy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zpy.pojo.Food;
import org.springframework.stereotype.Repository;

@Repository
public interface FoodMapper extends BaseMapper<Food> {
}
