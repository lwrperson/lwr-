package com.zpy.pojo;

import lombok.Data;

@Data
public class CountNumber {
    private String name;
    private String count;
}
