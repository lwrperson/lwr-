package com.zpy.pojo;

import lombok.Data;


@Data
public class MainMenu {
    private String type;
    private Integer mount;
}
