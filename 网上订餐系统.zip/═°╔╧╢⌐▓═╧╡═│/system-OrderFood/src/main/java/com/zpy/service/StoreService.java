package com.zpy.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zpy.pojo.Store;

public interface StoreService extends IService<Store> {
}
