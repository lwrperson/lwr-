package com.zpy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zpy.pojo.Store;
import org.springframework.stereotype.Repository;

@Repository
public interface StoreMapper extends BaseMapper<Store> {
}
