package com.zpy.pojo;

import lombok.Data;

@Data
public class MainMenu1 {
    private String type;
    private Double mount;
}
