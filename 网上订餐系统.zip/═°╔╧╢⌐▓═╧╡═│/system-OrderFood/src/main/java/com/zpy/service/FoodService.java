package com.zpy.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zpy.pojo.Food;

public interface FoodService extends IService<Food> {
}
