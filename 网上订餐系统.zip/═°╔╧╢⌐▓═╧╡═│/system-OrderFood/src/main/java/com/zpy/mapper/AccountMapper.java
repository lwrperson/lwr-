package com.zpy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zpy.pojo.User;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountMapper extends BaseMapper<User> {
}
